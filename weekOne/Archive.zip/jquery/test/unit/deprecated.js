QUnit.module( "deprecated", { teardown: moduleTeardown } );

